--
-- Database: `shoes_test`
--
CREATE DATABASE IF NOT EXISTS `shoes_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `shoes_test`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`) VALUES
(198, 'Straight Ahead Shoes'),
(199, 'Straight Ahead Shoes'),
(200, 'Straight Ahead Shoes');

-- --------------------------------------------------------

--
-- Table structure for table `brand_store`
--

CREATE TABLE `brand_store` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brand_store`
--

INSERT INTO `brand_store` (`id`, `brand_id`, `store_id`) VALUES
(1, 21, 21),
(2, 22, 21),
(3, 33, 32),
(4, 34, 32),
(5, 45, 43),
(6, 46, 43),
(7, 57, 54),
(8, 58, 54),
(9, 69, 65),
(10, 70, 65),
(11, 81, 76),
(12, 82, 76),
(13, 93, 77),
(14, 94, 77),
(15, 105, 78),
(16, 106, 78),
(17, 107, 89),
(18, 108, 89),
(19, 119, 90),
(20, 120, 91),
(21, 121, 91),
(22, 122, 102),
(23, 123, 102),
(24, 134, 103),
(25, 135, 104),
(26, 137, 115),
(27, 138, 115),
(28, 149, 116),
(29, 150, 117),
(30, 150, 117),
(31, 152, 128),
(32, 153, 128),
(33, 164, 129),
(34, 165, 130),
(35, 165, 130),
(36, 167, 141),
(37, 168, 142),
(38, 169, 142),
(39, 180, 143),
(40, 181, 144),
(41, 181, 182),
(42, 183, 155),
(43, 184, 156),
(44, 185, 156),
(45, 196, 157),
(46, 197, 158),
(47, 197, 159),
(48, 198, 170),
(49, 199, 171),
(50, 200, 171);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `brand_store`
--
ALTER TABLE `brand_store`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201;
--
-- AUTO_INCREMENT for table `brand_store`
--
ALTER TABLE `brand_store`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=172;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
