--
-- Database: `shoes`
--
CREATE DATABASE IF NOT EXISTS `shoes` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `shoes`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`) VALUES
(1, 'Straight Aheads'),
(3, 'Giant Steps'),
(4, 'My Little Suede'),
(5, 'Sketchers (of Spain)'),
(6, 'No Chasers'),
(8, 'Weather Reporters'),
(9, 'Funky Bootsies'),
(10, 'Freddie Freeloaders');

-- --------------------------------------------------------

--
-- Table structure for table `brand_store`
--

CREATE TABLE `brand_store` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brand_store`
--

INSERT INTO `brand_store` (`id`, `brand_id`, `store_id`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 1, 6),
(4, 2, 5),
(5, 2, 5),
(6, 2, 6),
(7, 3, 7),
(8, 4, 8),
(9, 5, 9),
(10, 1, 9),
(11, 6, 6),
(12, 6, 9),
(13, 6, 7),
(14, 10, 9),
(15, 10, 11),
(16, 10, 7),
(17, 9, 14),
(18, 7, 1),
(19, 7, 12),
(20, 3, 10),
(21, 7, 10),
(22, 6, 10),
(23, 4, 13);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stores`
--

INSERT INTO `stores` (`id`, `name`) VALUES
(1, 'Basies Shoe Jam'),
(3, 'Dizzy Kicks'),
(6, 'Thelonious Footwear'),
(7, 'Coltrane and Co'),
(9, 'Miles of Shoes'),
(10, 'Pharaoh Sandals'),
(11, 'Evans Shoes'),
(12, 'Zawinul Boots and More'),
(13, 'Stern Footwear'),
(14, 'Shoe Parliament');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `brand_store`
--
ALTER TABLE `brand_store`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `brand_store`
--
ALTER TABLE `brand_store`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
